marks=input("what did the student score:")
marks=int(marks)
if marks>90:
  print("a")
elif marks >70:
  print("b")
elif marks >50:
    print("c")
else:
      print("d")