value=input("what is the value:")
value_1=input("enter value 1")
value_2=input("enter value 2"
    print("value 1 is greater")
else:
    print("value 2 is greater")